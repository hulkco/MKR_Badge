#define UF2_VERSION_BASE "v2.0.0-32-g2d4ec73-dirty"
